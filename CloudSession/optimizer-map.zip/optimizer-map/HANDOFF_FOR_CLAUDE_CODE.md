# Claude Codeへの引き継ぎ事項

このプロジェクトはクラウドセッションで作成した**プロトタイプ**である．
ローカルのClaude Codeが，ローカルリポジトリへ移植し，最終実装を行う前提で作成している．

## 1. 移植の手順

1. このプロジェクト一式をローカルリポジトリのルートに配置する．
   - 対象: `data/`，`site/`，`tools/`，`review/`，`.github/`，`package.json`，`package-lock.json`，`README.md`，`.gitignore`
2. ローカルリポジトリに既存の規約（`.ai/ai-dev-kit/documentation.md`，`.ai/ai-dev-kit/environment_construction.md` 等）がある場合は，そちらを優先して文書・ディレクトリ構成を合わせる．
3. ローカルに旧形式のデータ（`data/nodes/`）がある場合は，キー名を README のスキーマに合わせて統合する．
   - 本プロジェクトで追加したキー・ファイル: `short_name`（任意），`parents[].types`（必須），`categories.json` の `group`，`data/groups.json`，`data/improvement_types.json`，`data/metadata_overrides.json`
4. 動作確認（README の「ローカルでの実行」と同じ）．

```bash
npm ci
```

```bash
python tools/validate_nodes.py
```

```bash
node tools/check_formulas.mjs
```

```bash
python tools/build_graph.py
```

```bash
node tools/precompute_layout.mjs
```

```bash
python -m http.server 8000 -d site
```

5. **ネットワークが必要な処理はクラウドセッションでは未実行**のため，ローカルで最初に実行して確認すること．
   具体的な作業と完了条件は **`CLAUDE_CODE_TASKS.md`** にまとめてある．

## 2. 実装済みの機能と確認状況

クラウドセッションでヘッドレスChromium（Playwright）を用いて確認した（コンソールエラーなし）．
CDN（jsdelivr）に接続できない環境だったため，npmで取得した同一バージョンのD3・KaTeXをPlaywrightのルーティングで差し替えて確認した．本番のHTMLはCDNを参照している．

### 可視化（`site/`）

| 機能 | 実装箇所 | 状態 |
|---|---|---|
| Citation数に応じたノードの大きさ（対数，null は破線） | `layout.js` `makeRadiusScale` | 確認済み |
| 古いものを上・新しいものを下（存在する年ごとに横帯） | `layout.js` `computeLayout` | 確認済み |
| 分野グループの色分け（8色，ライト/ダーク） | `app.js` `injectGroupColors`，`groups.json` | 確認済み |
| 領域配置（全所属グループの間に置き，範囲を等高線で囲う）／列配置の切り替え | `layout.js`，`app.js` `setLayoutMode` | 確認済み |
| 配置の事前計算（graph.json に埋め込み．なければブラウザで計算） | `tools/precompute_layout.mjs`，`app.js` `getLayout` | 確認済み（両方） |
| 複数分野の外周リング，凡例ホバーで範囲を強調 | `renderLayout`，`applyRegionEmphasis` | 確認済み |
| 詳細パネル（共通フォーマット，KaTeX）と**論文リンク**（論文ページ・PDF・Google Scholar・Semantic Scholar） | `renderPanel`，`linkButtons` | 確認済み |
| 書誌情報（論文タイトル・著者・掲載先・Citation数の出典）の表示 | `metaList` | 表示の分岐は確認済み（実データ未取得） |
| 改良パターンの強調とエッジ上の略号（重なり回避あり） | `setPattern`，`renderBadges` | 確認済み |
| パターン表（パターン × 分野／年代） | `renderMatrix` | 確認済み |
| **改善アイデアの候補**（未適用セル「＋」→対象手法・他分野の適用例・生成AI相談用プロンプトのコピー） | `ideaBox` | 確認済み（クリップボードは目視未確認） |
| **比較ビュー**（最大3手法の並列表示） | `toggleCompare`，`renderCompare` | 確認済み |
| **系譜の経路**（直系の経路，または最も新しい共通の祖先からの2本の経路）とマップ上での表示 | `relation`，`showPathOnMap` | 確認済み |
| **年スライダー**と再生（指定年までの手法のみ表示，範囲もその年で切り取り） | `setupYearSlider`，`applyVisibility` | 確認済み |
| **ラベルの重なり解消**（優先度順に配置し，ラベル同士・他ノードの円との重なりを回避） | `updateLabels` | 確認済み |
| 検索，グループの表示/非表示，一覧表（状態量・実装・PDFリンク列付き），URLハッシュ，配色切り替え，スマートフォン幅 | 各関数 | 確認済み |
| **トレンドビュー**（分野グループ・改良パターンの年次推移の small multiples，直近の増加の自動抽出） | `renderTrend` | 確認済み |
| **実用情報**（状態量・実装・ハイパラ・用途）の表示と**絞り込み** | `practicalList`，`setupFilters`，`passFilters` | 確認済み |
| **解説の深掘り**（主要50手法） | `deepDive` | 確認済み |
| **書き出し**（BibTeX・CSV・SVG・PNG） | `setupExport`，`toBibtex`，`toCsv`，`serializeMap`，`exportPng` | 確認済み（ファイルの中身まで確認．クリップボードは未確認） |
| **E2E スモークテスト**（11項目） | `tests/e2e/smoke.cjs` | 確認済み（CI上では未実行） |

### データ・自動化（`tools/`，`.github/workflows/`）

| 機能 | ファイル | 状態 |
|---|---|---|
| データ検証（参照切れ・循環・年代逆転・語彙・URL形式・重複検出・文体・実用情報の語彙） | `tools/validate_nodes.py` | 確認済み |
| 組み合わせの提案（試作 v0）とバックテスト | `tools/propose_combinations.py`，`docs/combination_proposal.md` | 確認済み |
| 更新式の KaTeX 検証 | `tools/check_formulas.mjs` | 確認済み |
| graph.json の生成（論文リンク・書誌情報の統合） | `tools/build_graph.py` | 確認済み（書誌情報はダミーデータで確認） |
| Semantic Scholar からの書誌情報の取得 | `tools/fetch_metadata.py` | **未実行**（`--dry-run` のみ確認） |
| 参考文献のリンク切れ検出 | `tools/check_links.py` | **未実行** |
| arXiv 新着からの候補抽出 | `tools/discover_candidates.py` | **未実行**（点数付けのみ確認） |
| Gemini による手法ノードの生成 | `tools/generate_nodes_gemini.py` | **未実行**（プロンプト・スキーマ・検証のみ確認） |
| Pages デプロイ（PRでは検証のみ） | `.github/workflows/pages.yml` | **未実行** |
| 月次の書誌情報更新 → PR | `.github/workflows/metadata.yml` | **未実行** |
| 週次の新着取り込み → PR | `.github/workflows/discover.yml` | **未実行** |
| 月次のリンク確認 → Issue | `.github/workflows/links.yml` | **未実行** |

## 3. 未確認の処理

ネットワーク・GitHub が必要な処理（書誌情報の取得，リンク確認，新着の自動取り込み，ワークフローの初回実行，CI 上の E2E テスト）と，
ユーザーと一緒に行うデータのレビュー，組み合わせ提案 v1 の実装は，**`CLAUDE_CODE_TASKS.md`** に手順と完了条件をまとめた．

## 4. 既知の課題（優先度順）

1. **改良パターンの分類の確認**: 全407本の `types` はクラウドセッションのClaudeが付与した（全件を目視で修正済み）．境界的なもの（「理論的再解釈・一般化」と他パターン等）はユーザーのレビューで調整する．`review/nodes_review.md` に［パターン名］として表示される．
2. **領域配置の島**: 副分野の手法が離れた位置にあると，その分野の範囲が小さな島になる．案: 最寄りのメンバーと細い「橋」でつなぐ（Bubble Sets 方式）．範囲の形は `layout.js` の `LAYOUT_CONFIG.region` で調整する．
3. **エッジの過密**: SGD・Adam等の派生先が多い手法から長いエッジが多数伸びる．案: 全体表示ではグループ内のエッジのみ表示する切り替え，エッジのバンドリング．
4. **縦方向の間延び**: 1740〜2000年は手法が少なく上部が疎．案: 2000年以前の帯をまとめる．
5. **改善アイデアの候補の精度**（組み合わせ提案は `docs/combination_proposal.md` を参照）: 現状は「対象分野の手法を Citation数順」に並べるだけで，すでに類似の改良を受けている手法も含む．案: 手法ごとに受けた改良パターンを除外する，生成AIで候補を絞り込む．
6. **大きさの凡例**: 凡例の円は倍率1のときの大きさであり，ズーム中は一致しない．
7. **キーボード操作**: グラフ上のノードはキーボードでフォーカスできない（一覧表・比較ビューで代替）．

## 5. 設計上の決定事項（変更時に注意すること）

- **色は分野グループ（8色）に割り当て，分野タグ（22種）には割り当てない**．カテゴリカルな色は8色を超えると判別できなくなるため．
  - 列配置の色の並び（`groups.json` の `order`）は，隣り合う列の色の組が色覚多様性の判別基準を満たす順になっている．
  - ライトモードで黄・水色・桃色は背景とのコントラストが3:1未満のため，ノードのラベル表示と一覧表ビューを必須としている（削除しないこと）．
- **主分野は `categories[0]`** であり，主分野の所属グループで色と列が決まる．
- **領域配置のアンカーの並び**は，データから「同時に現れやすいグループ同士が隣り合う」順を全順列（8! 通り）から選んでいる（`layout.js` `optimizeGroupOrder`）．9グループにすると約36万通りになる．
- 領域配置では範囲が任意に重なるため，色だけに頼らず**範囲の輪郭線・範囲ラベル・凡例ホバーでの強調**を併用している．
- **改良パターンはエッジの色で表さない**（15種を色で区別できない）．強調とバッジ（略号）で表す．
- **配置計算は `site/assets/layout.js` に集約**し，ブラウザ（`app.js`）とビルド（`tools/precompute_layout.mjs`）で同じコードを使う．配置を変える場合はこのファイルだけを編集し，graph.json を再生成する．
- **PDF本体はリポジトリに置かない**（論文の多くは再配布が許諾されておらず，容量も大きいため）．arXiv のPDFリンク，参考文献がPDFの場合はそのURL，Semantic Scholar のオープンアクセス版のURLをリンクとして表示する．
- **ユーザー由来の文字列はすべて `textContent` で挿入**している（`innerHTML` を使わない）．リンクは `http(s)` のみ．
- 外部ライブラリはバージョンを固定している（D3 7.9.0，KaTeX 0.16.11．ブラウザはCDN，ビルドはnpm）．
